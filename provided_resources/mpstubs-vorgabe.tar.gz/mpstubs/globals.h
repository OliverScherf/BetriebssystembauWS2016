#ifndef __GLOBALS_H__
  #define __GLOBALS_H__

#define SETUP_AP_MAGIC 0xdead
#define SETUP_AP_CODE_ADDRESS 0x40000
#endif // __GLOBALS_H__
